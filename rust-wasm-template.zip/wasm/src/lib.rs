
use wasm_bindgen::prelude::*;

pub type JsResult<T> = Result<T, JsValue>;

// mod utils;
// #[wasm_bindgen]
// pub fn set_panic_hook() {
//     utils::set_panic_hook();
// }

// #[wasm_bindgen]
// extern {
//     #[wasm_bindgen(js_namespace = performance)]
//     fn now() -> f64;
//     #[wasm_bindgen(js_namespace = console)]
//     fn log(s: &str);
// }
