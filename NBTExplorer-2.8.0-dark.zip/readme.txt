the original application: https://github.com/jaquadro/NBTExplorer/releases/tag/v2.8.0-win

modifications I made with dnSpy:
  make node tree dark mode
    in NBTExplorer.Windows.MainForm::InitializeComponent()
      + using System.Drawing;

        this._nodeTree.TabIndex = 0;
      + this._nodeTree.BackColor = Color.FromArgb(30, 30, 30);
      + this._nodeTree.ForeColor = Color.White;
        this._buttonAddTagLongArray.DisplayStyle = ToolStripItemDisplayStyle.Image;
    in NBTExplorer.Windows.MainForm.resources.imageList1.ImageStream and NBTExplorer.Windows.FindReplace.resources.imageList1.ImageStream
      replace the images to dark mode
  make it dpi aware
    in NBTExplorer.Program
      add following class member
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool SetProcessDpiAwarenessContext(int value);
    in NBTExplorer.Program::Main(System.String[])      
        Application.SetCompatibleTextRenderingDefault(false);
      + SetProcessDpiAwarenessContext(-4);
        Application.Run(new MainForm());